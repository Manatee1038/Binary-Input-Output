#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define COURSE_FILE "courses.dat"

char buffer[85];

typedef struct {
    char course_Name[84];
    char course_Sched[4];
    unsigned course_Size;
    unsigned course_Hours;
    char padding[20];
} COURSE;

void printMenu() {
    printf("Enter one of the following actions or press CTRL-D to exit.\n");
    printf("C - create a new course record\n");
    printf("U - update an existing course record\n");
    printf("R - read an existing course record\n");
    printf("D - delete an existing course record\n");
}

void create(FILE * inFile) {
    int cNum;
    int courseRead;
    char cName[84];
    char cSchedule[4];
    unsigned cSize;
    unsigned cHours;
    COURSE course;
    
    printf("Course number: ");
    fgets(buffer, 10, stdin);
    sscanf(buffer, "%d", &cNum);

    printf("Course name: ");
    fgets(buffer, 85, stdin);
    if (buffer[strlen(buffer) - 1] == '\n')
        buffer[strlen(buffer) - 1] = '\0';
    strcpy(cName, buffer);

    printf("Course schedule: ");
    fgets(buffer, 10, stdin);
    if (buffer[strlen(buffer) - 1] == '\n')
        buffer[strlen(buffer) - 1] = '\0';
    strcpy(cSchedule, buffer);

    printf("Course credit hours: ");
    fgets(buffer, 10, stdin);
    if (sscanf(buffer, "%u", &cHours) == EOF)
        cHours = 0;

    printf("Course enrollment: ");
    fgets(buffer, 10, stdin);
    if (sscanf(buffer, "%u", &cSize) == EOF)
        cSize = 0;

    fseek(inFile, cNum * sizeof(COURSE), SEEK_CUR);
    courseRead = fread(&course, sizeof(COURSE), 1L, inFile);
    if (course.course_Hours != 0 && courseRead) {
        printf("ERROR: course already exists\n");
        return;
    }
    if (courseRead)
        fseek(inFile, -sizeof(COURSE), SEEK_CUR);

    strcpy(course.course_Name, cName);
    strcpy(course.course_Sched, cSchedule);
    course.course_Hours = cHours;
    course.course_Size = cSize;

    fwrite(&course, sizeof(COURSE), 1L, inFile);
}

void update(FILE * inFile) {
    int cNum;
    int courseRead;
    int hoursRead;
    int sizeRead;
    char cName[84];
    char cSchedule[4];
    unsigned cHours;
    unsigned cSize;
    COURSE courseOld;
    COURSE courseNew;

    printf("Course number: ");
    fgets(buffer, 10, stdin);
    sscanf(buffer, "%d", &cNum);

    printf("Course name: ");
    fgets(buffer, 85, stdin);
    if (buffer[strlen(buffer) - 1] == '\n')
        buffer[strlen(buffer) - 1] = '\0';
    strcpy(cName, buffer);

    printf("Course schedule: ");
    fgets(buffer, 10, stdin);
    if (buffer[strlen(buffer) - 1] == '\n')
        buffer[strlen(buffer) - 1] = '\0';
    strcpy(cSchedule, buffer);

    printf("Course credit hours: ");
    fgets(buffer, 10, stdin);
    hoursRead = sscanf(buffer, "%u", &cHours);

    printf("Course enrollment: ");
    fgets(buffer, 10, stdin);
    sizeRead = sscanf(buffer, "%u", &cSize);

    fseek(inFile, cNum * sizeof(COURSE), SEEK_CUR);
    courseRead = fread(&courseOld, sizeof(COURSE), 1L, inFile);
    if (courseOld.course_Hours == 0 || !courseRead) {
        printf("ERROR: course not found\n");
        return;
    }
    if (courseRead)
        fseek(inFile, -sizeof(COURSE), SEEK_CUR);

    (strcmp(cName, "") != 0) ? strcpy(courseNew.course_Name, cName) : strcpy(courseNew.course_Name, courseOld.course_Name);
    (strcmp(cSchedule, "") != 0) ? strcpy(courseNew.course_Sched, cSchedule) : strcpy(courseNew.course_Sched, courseOld.course_Sched);
    courseNew.course_Hours = (hoursRead != EOF) ? cHours : courseOld.course_Hours;
    courseNew.course_Size = (sizeRead != EOF) ? cSize : courseOld.course_Size;

    courseOld.course_Hours = 0;
    fwrite(&courseOld, sizeof(COURSE), 1L, inFile);
    fseek(inFile, -sizeof(COURSE), SEEK_CUR);

    fwrite(&courseNew, sizeof(COURSE), 1L, inFile);
}

void read(FILE * inFile) {
    int cNum;
    int courseRead;
    COURSE course;

    printf("Enter a CS course number: ");
    fgets(buffer, 10, stdin);
    sscanf(buffer, "%d", &cNum);

    fseek(inFile, cNum * sizeof(COURSE), SEEK_CUR);
    courseRead = fread(&course, sizeof(COURSE), 1L, inFile);
    if (course.course_Hours == 0 || !courseRead) {
        printf("ERROR: course not found\n");
        return;
    }

    printf("Course number: %d\n", cNum);
    printf("Course name: %s\n", course.course_Name);
    printf("Scheduled days: %s\n", course.course_Sched);
    printf("Credit hours: %u\n", course.course_Hours);
    printf("Enrolled Students: %u\n", course.course_Size);
}

void delete(FILE * inFile) {
    int cNum;
    int courseRead;
    COURSE course;

    printf("Enter a course number: ");
    fgets(buffer, 10, stdin);
    sscanf(buffer, "%d", &cNum);

    fseek(inFile, cNum * sizeof(COURSE), SEEK_CUR);
    courseRead = fread(&course, sizeof(COURSE), 1L, inFile);
    if (course.course_Hours == 0 || !courseRead) {
        printf("ERROR: course not found\n");
        return;
    }
    if (courseRead)
        fseek(inFile, -sizeof(COURSE), SEEK_CUR);

    course.course_Hours = 0;
    fwrite(&course, sizeof(COURSE), 1L, inFile);
    printf("%d was successfully deleted.\n", cNum);
}

int main() {
    char choice;
    FILE * inFile;

    inFile = fopen(COURSE_FILE, "rb+");
    if (inFile == NULL) {
        printf("New file\n");
        inFile = fopen(COURSE_FILE, "wb+");
    }

    do {
        printMenu();

        choice = fgetc(stdin);
        if (choice == EOF)
            break; 
        fgets(buffer, 5, stdin);

        switch (choice) {
            case 'c':
            case 'C':
                create(inFile);
                break;
            case 'u':
            case 'U':
                update(inFile);
                break;
            case 'r':
            case 'R':
                read(inFile);
                break;
            case 'd':
            case 'D':
                delete(inFile);
                break;
            default:
                printf("ERROR: invalid option\n");
                break;
        }
        fseek(inFile, 0, SEEK_SET);
        printf("\n");
    } while (1);

    fclose(inFile);
    return 0;
}
